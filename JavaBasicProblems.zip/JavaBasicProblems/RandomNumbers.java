package JavaBasicProblems;

import java.util.Scanner;

import static java.lang.Math.random;

public class RandomNumbers {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println(random());
    }
}
