package Arrays;

import java.util.Scanner;

public class Demo {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String inputLine=scanner.nextLine();
        String[] arrStrings=inputLine.split("");
        int[] numbersArr=new int[arrStrings.length];
        for(int i=0;i< numbersArr.length;i++)
        {
            numbersArr[i]=Integer.parseInt(arrStrings[i]);
        }
        System.out.println();
    }
}
