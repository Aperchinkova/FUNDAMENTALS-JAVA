package Articles20;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        List<Article> listOfArticles=new ArrayList<>();
        int n=Integer.parseInt(scanner.nextLine());
        for (int i=0;i<n;i++)
        {
            String[] input=scanner.nextLine().split(", ");
            String title=input[0];
            String content=input[1];
            String author=input[2];
            Article article=new Article(title,content,author);
            listOfArticles.add(article);
        }
        String command= scanner.nextLine();
        for(Article article:listOfArticles)
        {
            System.out.println(article.getTitle()+" - "+article.getContent()+": "+article.getAuthor());
        }
    }
}
