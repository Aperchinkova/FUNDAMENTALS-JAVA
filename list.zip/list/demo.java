package list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class demo {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        /*
        List<String> namesList=new ArrayList<>();
        namesList.add("Aya");
        namesList.add("Dzhu");
        namesList.add("Kaya");
        for(String name: namesList)
        {
            System.out.println(name);
        }
         */
        String inputLine=scanner.nextLine();
        List<String> items= Arrays.stream(inputLine.split(" "))
                .collect(Collectors.toList());
        List<Integer> numbersList=new ArrayList<>();
        for(int i=0;i< items.size();i++)
        {
            numbersList.add(Integer.parseInt(items.get(i)));
        }
        System.out.println();
    }
}
