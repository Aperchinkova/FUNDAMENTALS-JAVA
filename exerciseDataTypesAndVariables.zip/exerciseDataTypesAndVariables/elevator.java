package exerciseDataTypesAndVariables;

import java.util.Scanner;

public class elevator {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=Integer.parseInt(scanner.nextLine());
        int p=Integer.parseInt(scanner.nextLine());
        double courses=Math.ceil(n*1.0/p);
        System.out.printf("%.0f",courses);
    }
}
