package ExamPreparation;

import java.util.Scanner;

public class WorldTour {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        String stops= scanner.nextLine();
        //Hawai::Cyprys-Greece
        StringBuilder stopsBuilder=new StringBuilder(stops);

        String input= scanner.nextLine();
        while(!input.equals("Travel"))
        {
            if (input.contains("Add Stop"))
            {
                //Add Stop:{index}:{string}
                //1. command = "Add Stop:7:Rome".split(":") -> ["Add Stop", "7", "Rome"]
                int index=Integer.parseInt(input.split(":")[1]);
                String stopName=input.split(":")[2];
                if (isIndexValid(index,stopsBuilder))
                {
                    stopsBuilder.insert(index,stopName);
                }
            }
            else if(input.contains("Remove Stop"))
            {
                //Remove Stop:{start_index}:{end_index}
                //2. command = "Remove Stop:11:16".split(":") -> ["Remove Stop", "11", "16"]
                int index1=Integer.parseInt(input.split(":")[1]);
                int index2=Integer.parseInt(input.split(":")[2]);
                if(isIndexValid(index1,stopsBuilder)&&isIndexValid(index2,stopsBuilder))
                {
                    stopsBuilder.delete(index1,index2+1);
                }
            }
            else if(input.contains("Switch"))
            {
                //Switch:{old_string}:{new_string}
                //3. command = "Switch:Hawai:Bulgaria".split(":") -> ["Switch", "Hawai", "Bulgaria"]
                String oldString=input.split(":")[1];
                String newString=input.split(":")[2];
                if(stopsBuilder.toString().contains(oldString))
                {
                    String updatedText=stopsBuilder.toString().replace(oldString,newString);
                    stopsBuilder=new StringBuilder(updatedText);
                }
            }
            System.out.println(stopsBuilder);
            input= scanner.nextLine();
        }
        System.out.println("Ready for world tour! Planned stops: "+stopsBuilder);
    }
    //метод, който валидира индекс в текста stopsBuilder
    //true -> ако индексът е валиден
    //false -> ако индексът не е валиден
    private static boolean isIndexValid(int index,StringBuilder builder)
    {
        return index>=0 && index<=builder.length()-1;
    }
}
