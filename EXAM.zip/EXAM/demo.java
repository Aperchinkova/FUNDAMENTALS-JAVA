package EXAM;

import java.util.Scanner;

public class demo {
    public void printText(String text)
    {
        System.out.println("I love"+text);

    }
    /*
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        printText("Java");
    }

     */


}
