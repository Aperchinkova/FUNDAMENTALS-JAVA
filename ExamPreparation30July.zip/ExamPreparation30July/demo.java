package ExamPreparation30July;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class demo {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        List<String> cars=new ArrayList<>();
        cars.add("v");
        cars.add("b");
        cars.remove(0);
        System.out.println(cars);
    }
}
