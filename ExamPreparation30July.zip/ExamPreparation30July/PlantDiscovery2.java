package ExamPreparation30July;

import java.util.Scanner;

public class PlantDiscovery2 {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

    }
}
